<?php
    $name = 'ghgfh';
    $email = 'vbbcvbvb';
    $message = 'cxzcxzc';
    $from = 'From: yoursite.com'; 
    $to = 'rajendra.singh450@gmail.com'; 
    $subject = 'Customer Inquiry';
    $body = "From: $name\n E-Mail: $email\n Message:\n $message";
   
        if (mail ($to, $subject, $body, $from)) { 
            echo '<p>Your message has been sent!</p>';
        } else { 
            echo '<p>Something went wrong, go back and try again!</p>'; 
        }

?>